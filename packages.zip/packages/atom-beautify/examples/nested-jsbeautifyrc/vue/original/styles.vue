
<style lang="sass">
nav {
ul {
    margin: 0
    padding: 0
}
  li {
    display: inline-block
}
a {
    display: block
    }
}
</style>

<style lang="scss">
nav {
  ul {
    margin: 0;
    padding: 0;
  }
  li { display: inline-block; }
  a {
    display: block;
  }
}
</style>
