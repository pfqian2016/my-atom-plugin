Q($.ajax(...))
  .catch(function (response) {
    console.error(response);
  });
