# atom-fecs

## [baidu fecs](https://github.com/ecomfe/fecs) 代码检查atom插件

## 安装
    Search for and install `atom-fecs` or `fecs` in Atom's Settings view.

## 使用
    当文件打开，或者保存时会自动检查代码

## 功能
    * 目前只支持 js，css，html，less, sass 文件检查
    * 暂不支持代码格式化功能

![A screenshot of your package](https://raw.githubusercontent.com/8427003/atom-fecs/master/screenshot/screenshot.gif)
