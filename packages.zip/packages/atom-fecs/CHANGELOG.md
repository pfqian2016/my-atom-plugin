## 0.1.4 - Release
* recovery less

## 0.1.3 - Release
* remove less temporarily

## 0.1.1 - Release
* change reporter to 'baidu'

## 0.1.0 - Release
* add show diff style as the severity

## 0.0.6 - Release
* Every bug fixed

## 0.0.5 - First Release
* Every feature added
* Every bug fixed
