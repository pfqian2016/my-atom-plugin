module.exports = {
  allowLocalOverride: false,
  babelMapsAddUrl: true,
  babelMapsPath: "",
  babelSourcePath: "",
  babelTranspilePath: "",
  createMap: false,
  createTargetDirectories: false,
  createTranspiledCode: true,
  disableWhenNoBabelrcFileInPath: false,
  keepFileExtension: false,
  suppressSourcePathMessages: false,
  suppressTranspileOnSaveMessages: false,
  transpileOnSave: true,
  autoIndentJSX: true
};
