This is the atom plugin

Install by cloning this repo into your atom packages folder and running npm install